from django.apps import AppConfig


class DeviceVerifyConfig(AppConfig):
    name = 'device_verify'
